
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f43607afccb4fa8364a9ccb870b874a0c781f4c8
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Sun Jun 2 08:57:11 2024 +0200
        
            docs: add kjkent as a contributor for bug (#1649)
            
            * docs: update CONTRIBUTORS.md
            
            * docs: update .all-contributorsrc
            
            ---------
            
            Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
